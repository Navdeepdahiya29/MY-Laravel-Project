<nav class="sb-sidenav-menu-nested nav">
    <a class="nav-link" {{$attributes}}>{{$slot}}</a>
</nav>