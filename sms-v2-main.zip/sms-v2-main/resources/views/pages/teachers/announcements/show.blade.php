@extends('pages.teachers.teacher-content');
<!-- Slotted content -->
@section('content')
<h2>Announcement</h2>

<!--  -->

<script>
    $(document).ready(function() {
        // set page title
        $(document).prop('title', 'Announcement | Student Management System');
    });
</script>

@endsection