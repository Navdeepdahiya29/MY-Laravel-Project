@extends('pages.admin.admin-content')

@section('content')
    <h2>Message</h2>
@endsection
