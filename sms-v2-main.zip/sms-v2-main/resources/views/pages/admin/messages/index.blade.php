@extends('pages.admin.admin-content')

@section('content')
    <h2>Messages</h2>
@endsection
