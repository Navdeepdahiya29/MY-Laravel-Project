@extends('pages.admin.admin-content')

@section('content')
<h2>{{$class->name}} - {{$class->year}}</h2>
@endsection